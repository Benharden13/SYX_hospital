--因子表=包装数量,在旧系统中,因子是由个个药房进行维护,而不是在药品维护中进行维护
--旧系统数据转到新系统,就需要在包装表插入数据,再在仓库处方包装中进行维护
--tbWMMiniBuyList list 西药因子表
--UsingScopeFlag --使用范围  可用=3 , 0=停用
--西药
SELECT
  wm.MiniBuyFlag, --西药中的因子包装标志,该标志为1,则是有因子包装
  WMName,
  WMNo,
  WMSpec,
  DepartmentName,
  DepartmentID,
  Quantity,
  '1-'+cast(wm.WMID as varchar(10))
FROM tbWMMiniBuyList list
  INNER JOIN tbDepartment dept ON dept.DepartmentID = list.MedicineDepartmentID
  INNER JOIN tbWM wm ON wm.WMID = list.WMID
WHERE --DepartmentID = '2101' and
  list.UsingScopeFlag = '3' AND wm.IdleFlag = 0
--成药
union all
SELECT
  wm.MiniBuyFlag, --西药中的因子包装标志,该标志为1,则是有因子包装
  PCMName,
  PCMNo,
  PCMSpec,
  DepartmentName,
  DepartmentName,
  DepartmentID,
  Quantity,
  '2-'+cast(wm.PCMID as varchar(10))
FROM tbPCMMiniBuyList list
  INNER JOIN tbDepartment dept ON dept.DepartmentID = list.MedicineDepartmentID
  INNER JOIN tbPCM wm ON wm.PCMID = list.PCMID
WHERE --DepartmentID = '2101' and
  list.UsingScopeFlag = '3' AND wm.IdleFlag = 0
--草药
union all
SELECT
  wm.MiniBuyFlag, --西药中的因子包装标志,该标志为1,则是有因子包装
  TCMName,
  TCMNo,
  TCMSpec,
  DepartmentName,
  DepartmentName,
  DepartmentID,
  Quantity,
  '2-'+cast(wm.TCMID as varchar(10))
FROM tbTCMMiniBuyList list
  INNER JOIN tbDepartment dept ON dept.DepartmentID = list.MedicineDepartmentID
  INNER JOIN tbTCM wm ON wm.TCMID = list.TCMID
WHERE --DepartmentID = '2101' and
 wm.IdleFlag = 0;
--使用范围为3,药品删除标志为0
